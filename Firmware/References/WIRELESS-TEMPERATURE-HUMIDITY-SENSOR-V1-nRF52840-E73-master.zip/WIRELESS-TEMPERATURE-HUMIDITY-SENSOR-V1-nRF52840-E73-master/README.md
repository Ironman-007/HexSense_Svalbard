# WIRELESS-TEMPERATURE-HUMIDITY-SENSOR-nRF52840-E73 V1

Temperature and humidity sensor.

#### Don't donate to me, it doesn't work in this world: https://paypal.me/efektalab , just buy:

an assembled sensor without case - $16,5

with case(sla) - +$5

with case(fdm) - +$3,2

Contact: helloh@efektalab.com

Video: 

More info at http://efektalab.com/th52840 (still not working)


---


### Components (BOM):

STANDART VERSION

1. a. nRF 52840 E73-2G4M08S1C (U1) - https://ali.ski/Bc8_x

OR

1. b. nRF 52840 E73-2G4M08S1C (U1) - https://ali.ski/3p2PEK

OR

1. c. nRF 52840 E73-2G4M08S1C (U1) - https://ali.ski/c9UlL

2. a. SHT20 (U2) - https://ali.ski/IOV9p | https://ali.ski/_oyyY | https://ali.ski/u2XM1 | https://ali.ski/ghXrZ

OR

2. b. SI7020 (U2) - https://ali.ski/8mY7ym

3. 0603 SMD LED BLUE (D1) - https://ali.ski/xFiJD

4. TBH-CR2450-M03 (U5) - https://ali.ski/EXGxQL

5. 2x3P | 6pin | 1.27mm | SMT | Pin Header Female - http://ali.ski/tKqX1J

6. Micro Button Tact Switch SMD 4Pin 3X4X2.5MM White (U3, U4) - https://ali.ski/9t2Axp

8. 1210 Capacitor 200UF 10V (C3) - https://ali.ski/-mbmM

9. 0603 SMD 1/8W chip resistor 10K (R1, R2) - https://ali.ski/8WIRx

10. 0603 SMD 1/8W chip resistor 3K (R3, R4, R5) - https://ali.ski/8WIRx

11. Capacitor 100NF 0603 (C1, C2) - https://ali.ski/KMz2x

---

17. M1.4 4mm Round Head Micro Screws(4) - http://ali.ski/sV_W2

18. M1.4 5mm Round Head Micro Screws(4) - http://ali.ski/sV_W2


![WIRELESS TEMPERATURE HUMIDITY SENSOR nRF52840 E73 V1](https://github.com/smartboxchannel/WIRELESS-TEMPERATURE-HUMIDITY-SENSOR-V1-nRF52840-E73/blob/master/IMAGES/promo.jpg)
